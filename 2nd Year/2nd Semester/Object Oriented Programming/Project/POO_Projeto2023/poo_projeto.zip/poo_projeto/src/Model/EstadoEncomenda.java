package Model;

public enum EstadoEncomenda {
    Pendente,
    Finalizada,
    Expedida,
    Entregue
}
