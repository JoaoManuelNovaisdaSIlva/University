package Model;

public enum Dimenssao {
    Grande,
    Medio,
    Pequeno
}
