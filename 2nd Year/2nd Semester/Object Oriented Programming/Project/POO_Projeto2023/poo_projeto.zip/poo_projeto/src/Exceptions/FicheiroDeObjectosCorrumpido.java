package Exceptions;

public class FicheiroDeObjectosCorrumpido extends Exception{
    public FicheiroDeObjectosCorrumpido(String msg){
        super(msg);
    }
}
