package Model;

public enum TexturaMala {
    Pele,
    Tecido,
    Sintetico
}
