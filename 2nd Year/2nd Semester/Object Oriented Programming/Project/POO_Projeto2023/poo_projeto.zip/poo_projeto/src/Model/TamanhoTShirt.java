package Model;

public enum TamanhoTShirt {
    S,
    M,
    L,
    XL
}
