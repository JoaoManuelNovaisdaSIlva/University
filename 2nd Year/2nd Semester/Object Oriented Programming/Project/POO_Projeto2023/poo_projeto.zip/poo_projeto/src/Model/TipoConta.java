package Model;

public enum TipoConta {
    Comprador,
    Vendedor,
    Transportadora
}
