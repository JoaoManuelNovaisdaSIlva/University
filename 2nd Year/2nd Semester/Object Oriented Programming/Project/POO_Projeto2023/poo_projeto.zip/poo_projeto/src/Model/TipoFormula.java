package Model;

public enum TipoFormula {
    Default,
    Customized
}
