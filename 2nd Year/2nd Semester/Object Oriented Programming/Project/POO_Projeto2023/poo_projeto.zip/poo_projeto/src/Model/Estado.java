package Model;

public enum Estado {
    Bom,
    Medio,
    Mau
}
