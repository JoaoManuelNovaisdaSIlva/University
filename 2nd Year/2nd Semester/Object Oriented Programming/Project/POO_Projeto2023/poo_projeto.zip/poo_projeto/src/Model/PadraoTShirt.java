package Model;

public enum PadraoTShirt {
    Liso,
    Riscas,
    Palmeiras
}
