Este trabalho foi realizado pelos seguintes alunos:

- A91695 Tiago Carriço
- A90214 Ivo Lima
- A91660 Pedro Sequeira
- A91671 João Silva
- A91672 Luís Ferreira

Caso o zip fique corrompido, pode-se encontrar a resolução no meu GitHub:

https://github.com/Carricossauro/Programacao-Orientada-a-Objetos/tree/main/CasaInteligente/src/casainteligente
